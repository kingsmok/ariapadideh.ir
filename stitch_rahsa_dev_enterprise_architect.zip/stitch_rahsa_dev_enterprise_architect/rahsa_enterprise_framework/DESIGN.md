---
name: Rahsa Enterprise Framework
colors:
  surface: '#101417'
  surface-dim: '#101417'
  surface-bright: '#363a3d'
  surface-container-lowest: '#0b0f11'
  surface-container-low: '#191c1f'
  surface-container: '#1d2023'
  surface-container-high: '#272a2d'
  surface-container-highest: '#323538'
  on-surface: '#e0e2e6'
  on-surface-variant: '#c6c6ce'
  inverse-surface: '#e0e2e6'
  inverse-on-surface: '#2d3134'
  outline: '#909098'
  outline-variant: '#46464d'
  surface-tint: '#bfc5e4'
  primary: '#bfc5e4'
  on-primary: '#292f48'
  primary-container: '#0a1128'
  on-primary-container: '#767c99'
  inverse-primary: '#575d78'
  secondary: '#ffb953'
  on-secondary: '#452b00'
  secondary-container: '#c68302'
  on-secondary-container: '#3c2500'
  tertiary: '#b9c6ea'
  on-tertiary: '#23304d'
  tertiary-container: '#04112d'
  on-tertiary-container: '#717d9e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#bfc5e4'
  on-primary-fixed: '#141a32'
  on-primary-fixed-variant: '#3f465f'
  secondary-fixed: '#ffddb4'
  secondary-fixed-dim: '#ffb953'
  on-secondary-fixed: '#291800'
  on-secondary-fixed-variant: '#633f00'
  tertiary-fixed: '#d9e2ff'
  tertiary-fixed-dim: '#b9c6ea'
  on-tertiary-fixed: '#0d1b36'
  on-tertiary-fixed-variant: '#3a4664'
  background: '#101417'
  on-background: '#e0e2e6'
  surface-variant: '#323538'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 60px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
  headline-md:
    fontFamily: Manrope
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-sm:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  code-sm:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
  stack-xs: 4px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style
The design system is engineered for a premium B2B software house, blending the structural rigor of enterprise architecture with the ethereal aesthetics of **Premium Glassmorphism**. The visual narrative is built upon "Digital Craftsmanship"—positioning the agency as a high-end atelier for software.

The emotional response should be one of absolute trust, technical mastery, and modern sophistication. By utilizing deep navy tones and royal gold accents, the UI reflects authority and value. The "Glassmorphism" implementation is restrained, used primarily to denote hierarchy and modularity rather than as a decorative gimmick. 

**Design Style: Enterprise Glassmorphism**
- **Clarity over Chaos:** High-blur backgrounds ensure legibility while maintaining a sense of depth.
- **Architectural Integrity:** Elements follow a strict 8px grid, reflecting the SOLID and DRY principles of the underlying codebases.
- **Premium Materiality:** Surfaces mimic frosted sapphire glass, providing a high-end feel that distinguishes the product from standard corporate SaaS.

## Colors
The palette is rooted in a "Midnight & Gold" theme to evoke professionalism and premium service.

- **Primary & Deep Neutral:** The foundation uses `#0A1128` for the deepest backgrounds, transitioning to `#14213D` for surface containers.
- **Accent (Royal Gold):** `#FBB03B` is reserved strictly for high-value Actions, CTAs, and critical success indicators. It represents the "premium" output of the agency.
- **Glass Layers:** Surfaces use a semi-transparent hex code with a backdrop-filter (blur: 20px-40px). 
- **Typography:** White (#FFFFFF) for high emphasis, Gray-300 (#D1D5DB) for secondary body text, and Gray-500 (#6B7280) for disabled or placeholder states.

## Typography
The typography system is designed for a **Right-to-Left (RTL)** environment, optimized for Persian legibility while maintaining a modern, technical edge.

- **Typeface Selection:** While the technical implementation uses **Manrope** for its balanced, modern grotesque look (excellent for numbers and global SaaS aesthetics), it should be paired with **Vazirmatn** for all Persian strings to ensure high readability in technical documentation.
- **Scale:** A tight typographic scale ensures that data-heavy ERP and CRM interfaces remain functional.
- **RTL Handling:** All alignments are right-aligned by default. Line heights are slightly increased (1.6x for body) to accommodate Persian script descenders and ascenders without crowding.
- **Labels:** Use **Geist** for labels and technical data to reinforce the "Dev" nature of the brand.

## Layout & Spacing
This design system employs a **12-column fluid grid** for desktop and a **4-column fluid grid** for mobile.

- **8pt Grid System:** All spacing, padding, and margins must be multiples of 8px to ensure visual rhythm and "Clean Architecture" in the UI.
- **RTL Layout:** The layout "flips" across the vertical axis. Navigation starts from the right, and the sidebar is anchored to the right edge.
- **Logic of Flow:** Information should flow from Top-Right to Bottom-Left. Use generous "Safe Areas" around glass containers (minimum 32px) to allow the background blur to be visible, creating the illusion of floating depth.

## Elevation & Depth
Elevation is communicated through **Tonal Opacity** and **Backdrop Blurs** rather than traditional black shadows.

1.  **Level 0 (Base):** Deep Navy (#0A1128).
2.  **Level 1 (Cards/Sections):** 70% Opacity #14213D with 20px Backdrop Blur. A 1px solid border at 10% white opacity is mandatory to define edges.
3.  **Level 2 (Modals/Popovers):** 85% Opacity #14213D with 40px Backdrop Blur. Inner glow (top-left 1px border) adds a "glass edge" effect.
4.  **Shadows:** When used, shadows must be tinted with the primary navy (#050814) at 40% opacity, with a high spread and low blur to feel "heavy" and stable.

## Shapes
The shape language is "Soft Professional." 

- **Corner Radii:** A base of 8px (`0.5rem`) is used for buttons and input fields. Larger containers like cards use 16px (`1rem`). 
- **Consistency:** Avoid pill-shaped buttons; stick to the defined 8px radius to maintain a structural, enterprise-grade appearance.
- **Interactive States:** On hover, glass surfaces should increase in "thickness" (opacity increases from 70% to 85%) rather than changing physical size.

## Components
- **Buttons:** 
  - *Primary:* Solid Gold (#FBB03B) with Navy text. No border.
  - *Secondary:* Glass background with 1px gold border.
  - *Tertiary:* Ghost style, white text, no background.
- **Input Fields:** Dark navy background (10% darker than the container) with a 1px border that glows Gold (#FBB03B) only on focus.
- **Chips/Badges:** Used for "Tech Stack" tags. Small 4px radius, low-contrast navy backgrounds with Gray-300 text.
- **Cards:** The hallmark of this design system. Must feature a subtle linear gradient border (top-right to bottom-left) from white (15% opacity) to white (0% opacity) to catch light.
- **Data Tables:** High-density, minimal borders. Header rows use a 5% white tint background to separate from the body.
- **Project Progress Bar:** Uses a gold-to-orange gradient to show "Premium Growth."